package FourthSmallestElement;

import java.util.Arrays;

  public class FourthSmallestElement {
    public static void main(String args[]) {
        int[] unsortedList = {12,3,5,7,4,19,26};
        int fourthSmallest = findFourthSmallest(unsortedList);
        System.out.println("Fourth smallest element: " + fourthSmallest);
    }

    public static int findFourthSmallest(int[] arr) {
        if (arr.length < 4) {
            System.out.println("List is too small to find the fourth smallest element.");
            return -1; // or throw an exception based on your requirements
        }

        Arrays.sort(arr);
        return arr[1];
    }
}
		

	