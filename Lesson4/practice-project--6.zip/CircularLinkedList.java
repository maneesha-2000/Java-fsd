package circularLinkedList;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

 public class CircularLinkedList {
    Node head;

    // Function to insert a new element into the sorted circular linked list
    void insert(int newData) {
        Node newNode = new Node(newData);

        if (head == null) {
            head = newNode;
            head.next = head;
        } else if (newData <= head.data) {
            Node temp = head;
            while (temp.next != head) {
                temp = temp.next;
            }
            temp.next = newNode;
            newNode.next = head;
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != head && temp.next.data < newData) {
                temp = temp.next;
            }
            newNode.next = temp.next;
            temp.next = newNode;
        }
    }

    // Function to display the circular linked list
    void display() {
        if (head == null) {
            return;
        }
        Node temp = head;
        do {
            System.out.print(temp.data + " ");
            temp = temp.next;
        } while (temp != head);
    }
}

// Example usage:
 class Main {
    public static void main(String[] args) {
        CircularLinkedList clist = new CircularLinkedList();
        clist.insert(3);
        clist.insert(5);
        clist.insert(7);
        clist.insert(9);

        clist.display();
    }
}
