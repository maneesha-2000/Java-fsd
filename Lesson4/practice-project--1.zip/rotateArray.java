package RotateArray;

public class rotateArray {

	
		    public static void main(String[] args) {
		        int[] array = {1, 2, 3, 4, 5, 6, 7}; // Replace this with your array

		        
		        int steps = 5;

		        
		        
		        
		        rightRotateArray(array, steps);

		        
		        System.out.println("Rotated Array: " + java.util.Arrays.toString(array));
		    }

		    private static void rightRotateArray(int[] arr, int steps) {
		        int length = arr.length;
		        steps = steps % length; 

		        
		        int[] temp = new int[steps];

		        
		        System.arraycopy(arr, length - steps, temp, 0, steps);

		        
		        System.arraycopy(arr, 0, arr, steps, length - steps);

		        
		        System.arraycopy(temp, 0, arr, 0, steps);
		    }
		

	}


