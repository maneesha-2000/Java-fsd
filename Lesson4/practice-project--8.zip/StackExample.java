package stack;

	

		import java.util.Stack;

		public class StackExample {

		    public static void main(String[] args) {
		        // Create a stack
		        Stack<Integer> stack = new Stack<>();

		        // Insert elements into the stack
		        stack.push(40);
		        stack.push(60);
		        stack.push(80);

		        System.out.println("Stack after insertion: " + stack);

		        // Remove elements from the stack
		        int poppedElement = stack.pop();
		        System.out.println("Popped element: " + poppedElement);
		        
		        System.out.println("Stack after removal: " + stack);
		    }
		}