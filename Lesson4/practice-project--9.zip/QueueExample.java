package queueExample;

import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {
    public static void main(String[] args) {
        // Create a Queue
        Queue<String> queue = new LinkedList<>();

        // Insert elements into the queue
        queue.offer("Banglore");
        queue.offer("Mumbai");
        queue.offer("Delhi");

        System.out.println("Queue after insertion: " + queue);

        // Remove elements from the queue
        String removedElement1 = queue.poll();
        System.out.println("Removed element: " + removedElement1);
        System.out.println("Queue after removing an element: " + queue);

        String removedElement2 = queue.poll();
        System.out.println("Removed element: " + removedElement2);
        System.out.println("Queue after removing another element: " + queue);
    }
}