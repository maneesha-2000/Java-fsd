package Arrays;

public class Arrays {

	public static void main(String[] args) {
		System.out.println("Single Dimensional Array ");
		int[] age= {18,4,6,9};
		for(int i=0;i<age.length;i++)
		{
		
		System.out.println("Elements of array: "+age[i]);
		
		System.out.println("/n");
		System.out.println("Multivalued Dimensional Array");
		int[][] b = {
	            {2, 4, 6, 8}, 
	            {3, 6, 9} };
	      
	      System.out.println("\nLength of row 1: " + b[0].length);
	      }
	}


		
		
		
		

	}

	

