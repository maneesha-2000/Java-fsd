package com.ecommerce.tests;

public class Calculator
{
	public int add(int a, int b) {
		// TODO Auto-generated method stub
		return a+b;
	}
}
