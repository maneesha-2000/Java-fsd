package ticketBooking;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class Theatre {
    private Map<String, Movie> movies;
    private boolean[][] seatMatrix;

    public Theatre() {
        this.movies = new HashMap<>();
        this.seatMatrix = new boolean[26][20];
        initializeSeatMatrix();
    }

    private void initializeSeatMatrix() {
        for (int i = 0; i < 26; i++) {
            for (int j = 0; j < 20; j++) {
                seatMatrix[i][j] = true;
            }
        }
    }

    public boolean[][] getSeatMatrix() {
        return seatMatrix;
    }

    public void addMovie(String startDate, String endDate, String showTime, Movie movie) {
        LocalDate start = LocalDate.parse(startDate);
        LocalDate end = LocalDate.parse(endDate);

        while (!start.isAfter(end)) {
            String date = start.toString();
            movies.put(date + "_" + showTime, movie);
            start = start.plusDays(1);
        }
    }
    
    public String checkAvailability(Movie movie, String[] selectedSeats) {
        for (String seat : selectedSeats) {
            int row = seat.charAt(0) - 'A';
            int col = Integer.parseInt(seat.substring(1)) - 1;

            // Check if the seat is within valid range and is available
            if (row >= 0 && row < 26 && col >= 0 && col < 20 && movie.getSeatingArrangement().get(seat)) {
                // Seat is valid and available, continue checking others
            } else {
                // Either the seat is out of range or already booked
                return "Selected seat " + seat + " is not available. Please choose different seats.";
            }
        }
        // All selected seats are valid and available
        return "Selected seats are available for booking.";
    }


    public Movie getMovie(String date, String showTime) {
        return movies.get(date + "_" + showTime);
    }
}
