package ticketBooking;


import java.util.Scanner;

public class MovieTicket {
    public static void main(String[] args) {
        Theatre theatre = new Theatre();
        Movie movie1 = new Movie("Inception", 50);
        Movie movie2 = new Movie("Avengers: Endgame", 30);

        theatre.addMovie("2022-01-05", "2022-02-05", "10AM", movie1);
        theatre.addMovie("2022-01-05", "2022-02-05", "4PM", movie1);

        theatre.addMovie("2022-01-06", "2022-02-06", "1PM", movie2);
        theatre.addMovie("2022-01-06", "2022-02-06", "7PM", movie2);

        FrontDesk frontDesk = new FrontDesk("admin", "password", theatre);

        Scanner scanner = new Scanner(System.in);

        // Login
        System.out.print("Enter username: ");
        String enteredUsername = scanner.next();
        System.out.print("Enter password: ");
        String enteredPassword = scanner.next();

        if (frontDesk.login(enteredUsername, enteredPassword)) {
            System.out.println("Login successful!");

            while (true) {
                System.out.println("\n1. Update Password");
                System.out.println("2. View Seating Arrangement");
                System.out.println("3. Book Ticket");
                System.out.println("4. Check Booking Status");
                System.out.println("5. Exit");
                System.out.print("Enter your choice: ");

                int choice = scanner.nextInt();
                scanner.nextLine(); // consume the newline character

                switch (choice) {
                    case 1:
                        System.out.print("Enter new password: ");
                        String newPassword = scanner.next();
                        frontDesk.updatePassword(newPassword);
                        break;
                    case 2:
                        System.out.print("Enter date (e.g., b/w 2022-01-05 to 2022-02-05): ");
                        String dateForView = scanner.next();
                        System.out.print("Enter show time: ");
                        String showTimeForView = scanner.next();
                        frontDesk.viewSeatingArrangement(dateForView, showTimeForView);
                        break;
                    case 3:
                        System.out.print("Enter date (e.g., b/w 2022-01-05 to 2022-02-05): ");
                        String dateForBooking = scanner.next();
                        System.out.print("Enter show time: ");
                        String showTimeForBooking = scanner.next();
                        System.out.print("Enter seat selection (e.g., B1,B2): ");
                        String seatSelection = scanner.next();
                        String[] selectedSeats = seatSelection.split(",");
                        frontDesk.bookTicket(dateForBooking, showTimeForBooking, selectedSeats);
                        break;
                    case 4:
                        System.out.print("Enter date (e.g., BETWEEN 2022-01-05 TO 2022-02-05): ");
                        String dateForStatus = scanner.next();
                        System.out.print("Enter show time: ");
                        String showTimeForStatus = scanner.next();
                        frontDesk.checkBookingStatus(dateForStatus, showTimeForStatus);
                        break;
                    case 5:
                        System.out.println("Exiting the program. Thank you!");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } else {
            System.out.println("Login failed. Exiting the program.");
        }
    }
}