package ticketBooking;

import java.util.HashMap;
import java.util.Map;

public class Movie {
    private String name;
    private int totalSeats;
    private Map<String, Boolean> seatingArrangement;

    public Movie(String name, int totalSeats) {
        this.name = name;
        this.totalSeats = totalSeats;
        this.seatingArrangement = new HashMap<>();
        initializeSeatMatrix();
    }
    
    private void initializeSeatMatrix() {
        for (char row = 'A'; row <= 'Z'; row++) {
            for (int col = 1; col <= 20; col++) {
                String seat = row + String.valueOf(col);
                seatingArrangement.put(seat, true); // true means seat is available
            }
        }
    }


    public String getName() {
        return name;
    }

    public int getTotalSeats() {
        return totalSeats;
    }

    public Map<String, Boolean> getSeatingArrangement() {
        return seatingArrangement;
    }

    public void bookSeats(String[] selectedSeats, boolean[][] seatMatrix) {
        for (String seat : selectedSeats) {
            int row = seat.charAt(0) - 'A';
            int col = Integer.parseInt(seat.substring(1)) - 1;
            seatingArrangement.put(seat, false);
            seatMatrix[row][col] = false;
        }
    }
}