package ticketBooking;

import java.util.Map;

public class FrontDesk extends User{
    private String username;
    private String password;
    private Theatre theatre;

    public FrontDesk(String username, String password, Theatre theatre) {
        super(username, password);
        this.theatre = theatre;
    }

    public boolean login(String enteredUsername, String enteredPassword) {
        return getUsername().equals(enteredUsername) && getPassword().equals(enteredPassword);
    }

    public void updatePassword(String newPassword) {
        password = newPassword;
        System.out.println("Password updated successfully.");
    }

    public void viewSeatingArrangement(String date, String showTime) {
        Movie movie = theatre.getMovie(date, showTime);
        if (movie != null) {
            Map<String, Boolean> seatingArrangement = movie.getSeatingArrangement();
            System.out.println("Seating arrangement for " + movie.getName() + " at " + showTime + ":");

            int rows = 26;
            int cols = 20;

            for (char row = 'A'; row < 'A' + rows; row++) {
                for (int col = 1; col <= cols; col++) {
                    String seat = row + String.valueOf(col);
                    System.out.print(seat + ": " + (seatingArrangement.get(seat) ? "Available" : "Booked") + "\t");
                }
                System.out.println(); // Move to the next line for the next row
            }
        } else {
            System.out.println("Movie not found!");
        }
    }



    public void bookTicket(String date, String showTime, String[] selectedSeats) {
        Movie movie = theatre.getMovie(date, showTime);
        if (movie != null) {
        	
        	for (String seat : selectedSeats) {
                String availabilityMessage = theatre.checkAvailability(movie, new String[]{seat});
                System.out.println("DEBUG: " + availabilityMessage);  // Print the availability message
            }
        	
            String availabilityMessage = theatre.checkAvailability(movie, selectedSeats);
            if (availabilityMessage.startsWith("Selected seats are available")) {
                double amount = calculateAmount(movie, selectedSeats);
                System.out.println("Amount: $" + amount);
                System.out.println("Booking confirmed!");
                movie.bookSeats(selectedSeats, theatre.getSeatMatrix());
            } else {
                System.out.println(availabilityMessage);
            }
        } else {
            System.out.println("Movie not found!");
        }
    }
    public void checkBookingStatus(String date, String showTime) {
        Movie movie = theatre.getMovie(date, showTime);
        if (movie != null) {
            Map<String, Boolean> seatingArrangement = movie.getSeatingArrangement();

            System.out.println("Booking status for " + movie.getName() + " at " + showTime + ":");

            int numRows = 26; // Assuming rows A to Z
            int numCols = 20; // Assuming columns 1 to 20

            for (char row = 'A'; row <= 'Z'; row++) {
                System.out.print(row + ": ");
                for (int col = 1; col <= numCols; col++) {
                    String seat = String.valueOf(row) + col;
                    System.out.print(seatingArrangement.get(seat) ? "O " : "X "); // "O" for available, "X" for booked
                }
                System.out.println(); // Move to the next row in the matrix
            }
        } else {
            System.out.println("Movie not found!");
        }
    }


    // Helper method to get the seat key based on row and column numbers
    private String getSeatKey(int row, int column) {
        char rowChar = (char) ('A' + row - 1);
        return rowChar + String.valueOf(column);
    }


    private double calculateAmount(Movie movie, String[] selectedSeats) {
        // Implement your logic to calculate the ticket amount based on the number of seats
        return selectedSeats.length * 10.0; // Assuming 10$ per seat
    }
}