package ticketBooking;



import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


 class User {
    protected String username;
    protected String password;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }
   public String getPassword() {
	   return password;
   }
}
 




 class Theatre {
    private Map<String, Movie> movies;
    private boolean[][] seatMatrix;

    public Theatre() {
        this.movies = new HashMap<>();
        this.seatMatrix = new boolean[26][20];
        initializeSeatMatrix();
    }

    private void initializeSeatMatrix() {
        for (int i = 0; i < 26; i++) {
            for (int j = 0; j < 20; j++) {
                seatMatrix[i][j] = true;
            }
        }
    }

    public boolean[][] getSeatMatrix() {
        return seatMatrix;
    }

    public void addMovie(String startDate, String endDate, String showTime, Movie movie) {
        LocalDate start = LocalDate.parse(startDate);
        LocalDate end = LocalDate.parse(endDate);

        while (!start.isAfter(end)) {
            String date = start.toString();
            movies.put(date + "_" + showTime, movie);
            start = start.plusDays(1);
        }
    }
    
    public String checkAvailability(Movie movie, String[] selectedSeats) {
        for (String seat : selectedSeats) {
            int row = seat.charAt(0) - 'A';
            int col = Integer.parseInt(seat.substring(1)) - 1;

            // Check if the seat is within valid range and is available
            if (row >= 0 && row < 26 && col >= 0 && col < 20 && movie.getSeatingArrangement().get(seat)) {
                // Seat is valid and available, continue checking others
            } else {
                // Either the seat is out of range or already booked
                return "Selected seat " + seat + " is not available. Please choose different seats.";
            }
        }
        // All selected seats are valid and available
        return "Selected seats are available for booking.";
    }


    public Movie getMovie(String date, String showTime) {
        return movies.get(date + "_" + showTime);
    }
}



  class FrontDesk extends User{
    

     private Theatre theatre;


	public FrontDesk(String username, String password, Theatre theatre) {
         super(username, password);
         this.theatre = theatre;
     }

     public boolean login(String enteredUsername, String enteredPassword) {
         return getUsername().equals(enteredUsername) && getPassword().equals(enteredPassword);
     }

     public void updatePassword(String newPassword) {
         password = newPassword;
         System.out.println("Password updated successfully.");
     }

     public void viewSeatingArrangement(String date, String showTime) {
         Movie movie = theatre.getMovie(date, showTime);
         if (movie != null) {
             Map<String, Boolean> seatingArrangement = movie.getSeatingArrangement();
             System.out.println("Seating arrangement for " + movie.getName() + " at " + showTime + ":");

             int rows = 26;
             int cols = 20;

             for (char row = 'A'; row < 'A' + rows; row++) {
                 for (int col = 1; col <= cols; col++) {
                     String seat = row + String.valueOf(col);
                     System.out.print(seat + ": " + (seatingArrangement.get(seat) ? "Available" : "Booked") + "\t");
                 }
                 System.out.println(); // Move to the next line for the next row
             }
         } else {
             System.out.println("Movie not found!");
         }
     }



     public void bookTicket(String date, String showTime, String[] selectedSeats) {
         Movie movie = theatre.getMovie(date, showTime);
         if (movie != null) {
         	
         	for (String seat : selectedSeats) {
                 String availabilityMessage = theatre.checkAvailability(movie, new String[]{seat});
                 System.out.println("DEBUG: " + availabilityMessage);  // Print the availability message
             }
         	
             String availabilityMessage = theatre.checkAvailability(movie, selectedSeats);
             if (availabilityMessage.startsWith("Selected seats are available")) {
                 double amount = calculateAmount(movie, selectedSeats);
                 System.out.println("Amount: $" + amount);
                 System.out.println("Booking confirmed!");
                 movie.bookSeats(selectedSeats, theatre.getSeatMatrix());
             } else {
                 System.out.println(availabilityMessage);
             }
         } else {
             System.out.println("Movie not found!");
         }
     }
     public void checkBookingStatus(String date, String showTime) {
         Movie movie = theatre.getMovie(date, showTime);
         if (movie != null) {
             Map<String, Boolean> seatingArrangement = movie.getSeatingArrangement();

             System.out.println("Booking status for " + movie.getName() + " at " + showTime + ":");

             int numRows = 26; // Assuming rows A to Z
             int numCols = 20; // Assuming columns 1 to 20

             for (char row = 'A'; row <= 'Z'; row++) {
                 System.out.print(row + ": ");
                 for (int col = 1; col <= numCols; col++) {
                     String seat = String.valueOf(row) + col;
                     System.out.print(seatingArrangement.get(seat) ? "O " : "X "); // "O" for available, "X" for booked
                 }
                 System.out.println(); // Move to the next row in the matrix
             }
         } else {
             System.out.println("Movie not found!");
         }
     }


     // Helper method to get the seat key based on row and column numbers
     private String getSeatKey(int row, int column) {
         char rowChar = (char) ('A' + row - 1);
         return rowChar + String.valueOf(column);
     }


     private double calculateAmount(Movie movie, String[] selectedSeats) {
         // Implement your logic to calculate the ticket amount based on the number of seats
         return selectedSeats.length * 10.0; // Assuming 10$ per seat
     }
 }
 

   class Movie {
      private String name;
      private int totalSeats;
      private Map<String, Boolean> seatingArrangement;

      public Movie(String name, int totalSeats) {
          this.name = name;
          this.totalSeats = totalSeats;
          this.seatingArrangement = new HashMap<>();
          initializeSeatMatrix();
      }
      
      private void initializeSeatMatrix() {
          for (char row = 'A'; row <= 'Z'; row++) {
              for (int col = 1; col <= 20; col++) {
                  String seat = row + String.valueOf(col);
                  seatingArrangement.put(seat, true); // true means seat is available
              }
          }
      }


      public String getName() {
          return name;
      }

      public int getTotalSeats() {
          return totalSeats;
      }

      public Map<String, Boolean> getSeatingArrangement() {
          return seatingArrangement;
      }

      public void bookSeats(String[] selectedSeats, boolean[][] seatMatrix) {
          for (String seat : selectedSeats) {
              int row = seat.charAt(0) - 'A';
              int col = Integer.parseInt(seat.substring(1)) - 1;
              seatingArrangement.put(seat, false);
              seatMatrix[row][col] = false;
          }
      }
  }
  
  
  
  
  


public class MovieTicket {
    public static void main(String[] args) {
        Theatre theatre = new Theatre();
        Movie movie1 = new Movie("Inception", 50);
        Movie movie2 = new Movie("Avengers: Endgame", 30);

        theatre.addMovie("2022-01-05", "2022-02-05", "10AM", movie1);
        theatre.addMovie("2022-01-05", "2022-02-05", "4PM", movie1);

        theatre.addMovie("2022-01-06", "2022-02-06", "1PM", movie2);
        theatre.addMovie("2022-01-06", "2022-02-06", "7PM", movie2);

        FrontDesk frontDesk = new FrontDesk("admin", "password", theatre);

        Scanner scanner = new Scanner(System.in);

        // Login
        System.out.print("Enter username: ");
        String enteredUsername = scanner.next();
        System.out.print("Enter password: ");
        String enteredPassword = scanner.next();

        if (frontDesk.login(enteredUsername, enteredPassword)) {
            System.out.println("Login successful!");

            while (true) {
                System.out.println("\n1. Update Password");
                System.out.println("2. View Seating Arrangement");
                System.out.println("3. Book Ticket");
                System.out.println("4. Check Booking Status");
                System.out.println("5. Exit");
                System.out.print("Enter your choice: ");

                int choice = scanner.nextInt();
                scanner.nextLine(); // consume the newline character

                switch (choice) {
                    case 1:
                        System.out.print("Enter new password: ");
                        String newPassword = scanner.next();
                        frontDesk.updatePassword(newPassword);
                        break;
                    case 2:
                        System.out.print("Enter date (e.g., b/w 2022-01-05 to 2022-02-05): ");
                        String dateForView = scanner.next();
                        System.out.print("Enter show time: ");
                        String showTimeForView = scanner.next();
                        frontDesk.viewSeatingArrangement(dateForView, showTimeForView);
                        break;
                    case 3:
                        System.out.print("Enter date (e.g., b/w 2022-01-05 to 2022-02-05): ");
                        String dateForBooking = scanner.next();
                        System.out.print("Enter show time: ");
                        String showTimeForBooking = scanner.next();
                        System.out.print("Enter seat selection (e.g., B1,B2): ");
                        String seatSelection = scanner.next();
                        String[] selectedSeats = seatSelection.split(",");
                        frontDesk.bookTicket(dateForBooking, showTimeForBooking, selectedSeats);
                        break;
                    case 4:
                        System.out.print("Enter date (e.g., BETWEEN 2022-01-05 TO 2022-02-05): ");
                        String dateForStatus = scanner.next();
                        System.out.print("Enter show time: ");
                        String showTimeForStatus = scanner.next();
                        frontDesk.checkBookingStatus(dateForStatus, showTimeForStatus);
                        break;
                    case 5:
                        System.out.println("Exiting the program. Thank you!");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } else {
            System.out.println("Login failed. Exiting the program.");
        }
    }
}