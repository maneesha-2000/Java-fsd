package collections;
import java.util.*;

public class collections {

	public static void main(String[] args) {
		System.out.println("ArrayList");
		ArrayList<String>list=new ArrayList<String>();
		list.add("Rama");
		list.add("vijaya");
		list.add("ravinder");
		list.add("Ajay");
		System.out.println(list);
		
		
		System.out.println("\n");
		System.out.println("Vector");
		Vector<String>v=new Vector<String>();
		v.add("ravi");
		v.add("Amit");
		v.add("Ajay");
		v.add("Arun");
		System.out.println(v);
		
		System.out.println("\n");
		System.out.println("LinkedList");
		LinkedList<String>city=new LinkedList<String>();
		city.add("Banglore");
		city.add("Chennai");
		Iterator<String>itr=city.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());	
			}
		

	    System.out.println("\n");
	    System.out.println("HashSet");
	    HashSet<Integer> set=new HashSet<Integer>();  
	    set.add(102);  
	    set.add(103);  
	    set.add(106);
	    set.add(109);
	    System.out.println(set);
	    
	    System.out.println("\n");
	    System.out.println("LinkedHashSet");
	    LinkedHashSet<Integer> set2=new LinkedHashSet<Integer>();  
	    set2.add(18);  
	    set2.add(20);  
	    set2.add(15);
	    set2.add(19);	       
	    System.out.println(set2);
	    } 	
		}


