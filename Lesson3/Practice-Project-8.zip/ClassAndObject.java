package oops;
class person{
	String name;
	int age;
	public person(String name,int age) {
		this.name=name;
		this.age=age;
		
	}
	public void displayInfo() {
		System.out.println("Name:"+name);
		System.out.println("Age:"+age);
	}
}

public class ClassAndObject {
	public static void main(String args[]) {
		person person1=new person("Cathrine",20);
		person person2=new person("James",25);
		System.out.println("Person1:");
		person1.displayInfo();
		System.out.println("\nPerson2:");
		person2.displayInfo();
		
	}
}

	
	

	
