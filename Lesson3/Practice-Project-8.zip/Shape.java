package oops;

public abstract class Shape {

	
		    // Abstract method for calculating area (to be implemented by subclasses)
		    public abstract double calculateArea();

		    // Concrete method
		    public void displayInfo() {
		        System.out.println("This is a shape.");
		    }
		}

		
		interface Drawable {
		    void draw();
		}

		
		class Circle extends Shape implements Drawable {
		    private double radius;

		    // Constructor
		    public Circle(double radius) {
		        this.radius = radius;
		    }

		    
		    @Override
		    public double calculateArea() {
		        return Math.PI * radius * radius;
		    }

		    // Implement the method from "Drawable"
		    @Override
		    public void draw() {
		        System.out.println("Drawing a circle.");
		    }
		}

		
		 class Main {
		    public static void main(String[] args) {
		        // Create an object of the concrete class "Circle"
		        Circle circle = new Circle(5.0);

		        // Call methods from the abstract class and interface
		        circle.displayInfo();
		        System.out.println("Area of the circle: " + circle.calculateArea());
		        circle.draw();
		    }
		}
