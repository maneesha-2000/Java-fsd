
import jakarta.servlet.Filter;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import java.io.IOException;

@WebFilter("/Account/*")
public class LoginFilter implements Filter {

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        String userId = request.getParameter("userid");

        if (userId != null && !userId.isEmpty()) {
            chain.doFilter(request, response);
        } else {
            response.getWriter().write("Access denied. Please provide a valid user ID.");
        }
    }
    // Other methods (destroy, init) can remain as is
}