

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/SessionServlet")
public class SessionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the username from the form
        String username = request.getParameter("username");

        // Create or retrieve session
        HttpSession session = request.getSession(true);

        // Set session attribute with the username
        session.setAttribute("username", username);

        // Create a cookie to store the username
        Cookie usernameCookie = new Cookie("username", username);

        // Set the cookie's expiration time (optional)
        usernameCookie.setMaxAge(60 * 60 * 24 * 7); // 1 week in seconds

        // Add the cookie to the response
        response.addCookie(usernameCookie);

        // Display a response to the user
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><head><title>Session Tracking with Cookies</title></head><body>");
        out.println("<h2>Session Tracking with Cookies</h2>");
        out.println("<p>Hello, " + username + "!</p>");
        out.println("<p>Session ID: " + session.getId() + "</p>");
        out.println("<p><a href='LogoutServlet'>Logout</a></p>");
        out.println("</body></html>");
        out.close();
    }
}