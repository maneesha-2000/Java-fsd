

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
		response.setContentType("text/html");
        String username = request.getParameter("username");
        

        // Validate the username and password (not shown in this example)

        // Create a session
        HttpSession session = request.getSession(true);
        session.setAttribute("username", username);

        // Redirect to Jakarta EE Dashboard servlet
        response.sendRedirect("DashboardServlet");
    }
}