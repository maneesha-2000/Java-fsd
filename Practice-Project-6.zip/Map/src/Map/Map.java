package Map;



	import java.util.*;
import java.util.Map.Entry;
	public class Map {

		public static void main(String[] args) {
			// map
			
			
			HashMap<Integer,String> hm=new HashMap<Integer,String>();      
		      hm.put(1,"Tony");    
		      hm.put(2,"Marin");    
		      hm.put(3,"cathrine");   
		       
		      System.out.println("\nThe elements of Hashmap are ");  
		      for(Entry<Integer, String> m:hm.entrySet()){    
		       System.out.println(m.getKey()+" "+m.getValue());    
		      }
		      
		     //HashTable
		       
		      Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
		      
		      ht.put(4,"Aals");  
		      ht.put(5,"Rosy");  
		      ht.put(6,"Jackey");  
		        

		      System.out.println("\nThe elements of HashTable are ");  
		      for(Entry<Integer, String> n:ht.entrySet()){    
		       System.out.println(n.getKey()+" "+n.getValue());    
		      }
		      
		      
		      
		      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
		      map.put(7,"Annebella");    
		      map.put(8,"Carlote");    
		      map.put(9,"Catrinee");       
		      
		      System.out.println("\nThe elements of TreeMap are ");  
		      for(Entry<Integer, String> l:map.entrySet()){    
		       System.out.println(l.getKey()+" "+l.getValue());    
		      }    
		      
		   }  
	}




	

