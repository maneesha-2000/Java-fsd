function calculateArea(length, width) {
    return length * width;
}

// Prototype for creating a Person object
function Person(name, age) {
    this.name = name;
    this.age = age;
}

// Method to greet a person
Person.prototype.greet = function() {
    return "Hello, my name is " + this.name + " and I am " + this.age + " years old.";
};


const rectangleArea = calculateArea(8, 4);
console.log("Area of the rectangle:", rectangleArea);

const person1 = new Person("John", 28);
console.log(person1.greet());

