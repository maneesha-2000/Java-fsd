// IIFE (Immediately Invoked Function Expression)
(function() {
    console.log("This is an IIFE");
})();

// Callback function example
function greet(name, callback) {
    console.log("Hello, " + name + "!");
    callback();
}

function sayGoodbye() {
    console.log("Goodbye!");
}

greet("Alice", sayGoodbye);

// Closure example
function counter() {
    var count = 0;
    return function() {
        return ++count;
    };
}

var incrementCounter = counter();
console.log(incrementCounter()); // Output: 1
console.log(incrementCounter()); // Output: 2
console.log(incrementCounter()); // Output: 3
