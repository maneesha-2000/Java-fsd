// Using Maps
let employee = new Map();

employee.set('name', 'John Doe');
employee.set('age', 30);
employee.set('designation', 'Software Engineer');

console.log(employee.get('name')); 
console.log(employee.get('age')); 
console.log(employee.get('designation')); 

// Using Classes
class Person {
  constructor(name, age) {
    this.name = name;
    this.age = age;
  }

  greet() {
    console.log(`Hello, my name is ${this.name} and I am ${this.age} years old.`);
  }
}

let person1 = new Person('Alice', 25);
person1.greet(); 
