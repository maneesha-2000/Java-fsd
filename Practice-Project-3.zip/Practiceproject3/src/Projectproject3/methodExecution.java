package Projectproject3;
public class methodExecution{



public int multipynumbers(int a,int b) {
	int z=a*b;
	return z;
}

public static void main(String[] args) {

	methodExecution b=new methodExecution();
	int ans= b.multipynumbers(10,5);
	System.out.println("Multipilcation is :"+ans);
	}



public class callMethod {

int val=200;

int operation(int val) {
	val =val*10/100;
	return(val);
}


public static void main(String args[]) {
	callMethod d = new callMethod();
	System.out.println("Before operation value of data is "+d.val);
	d.operation(100);
	System.out.println("After operation value of data is "+d.val);
	}






public class overloadMethod {
	
public void area(int b,int h)
    {
         System.out.println("Area of Triangle : "+(0.5*b*h));
    }
    public void area(int r) 
    {
         System.out.println("Area of Circle : "+(3.14*r*r));
    }

    public static void main(String args[])
    {

overloadMethod obj=new overloadMethod();
       obj.area(10,14);
       obj.area(9);  
   }
}
}





   







	
	
	

